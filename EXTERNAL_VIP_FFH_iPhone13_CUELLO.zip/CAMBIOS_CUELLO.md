Se integró CUELLO 👹 en la sección FRE FFH.

- Se añadió como opción con el mismo control visual de activar/desactivar que las demás.
- Se incluyó el paquete CUELLO.3105 proporcionado en ProtectedPackages y en los recursos del proyecto Xcode.
- Se añadió recuperación del estado al abrir la pantalla y restauración al desactivar.
- Se amplió la lectura del formato de paquete para aceptar el schemaVersion 3 del archivo recibido.

Nota: el proyecto fue actualizado a nivel de código y recursos; no se compiló una IPA en este entorno.
